import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SAI Talent Assess',
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SAI Talent Assess - Demo')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Welcome to the SIH25073 demo scaffold'),
            SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {},
              child: Text('Start Test (placeholder)'),
            ),
          ],
        ),
      ),
    );
  }
}