from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="SIH25073 Backend - Demo")

class Health(BaseModel):
    status: str

@app.get("/", response_model=Health)
def root():
    return {"status": "ok"}

@app.get("/ping")
def ping():
    return {"pong": True}

# Minimal submissions example
class Submission(BaseModel):
    user_phone: str
    test_type: str
    metrics: dict

submissions = []

@app.post("/submissions")
def create_submission(sub: Submission):
    sub_id = len(submissions) + 1
    entry = {"id": sub_id, "submission": sub.dict()}
    submissions.append(entry)
    return {"id": sub_id, "status": "received"}

@app.get("/submissions")
def list_submissions():
    return submissions