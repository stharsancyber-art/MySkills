export default function Home() {
  return (
    <main style={{padding: 24, fontFamily: 'Arial, sans-serif'}}>
      <h1>SAI Official Portal - Demo</h1>
      <p>This is a minimal Next.js placeholder for the SIH25073 dashboard.</p>
      <ul>
        <li><a href="http://localhost:8000">Backend (FastAPI) root</a></li>
        <li>Submissions can be POSTed to <code>/submissions</code> on backend.</li>
      </ul>
    </main>
  )
}